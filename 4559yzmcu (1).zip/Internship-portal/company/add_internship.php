<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$message = "";
$messageType = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $skills = trim($_POST['skills'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $stipend = trim($_POST['stipend'] ?? '');
    $duration = trim($_POST['duration'] ?? '');
    $company_id = (int) $_SESSION['user_id'];

    if (
        $title === '' ||
        $description === '' ||
        $skills === '' ||
        $location === '' ||
        $duration === ''
    ) {
        $message = "Please fill all required fields.";
        $messageType = "error";
    } elseif (!is_numeric($stipend) || (float)$stipend < 0) {
        $message = "Enter a valid stipend amount.";
        $messageType = "error";
    } else {
        $sql = "INSERT INTO internships
                (company_id, title, description, skills,
                 location, stipend, duration, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";

        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stipendAmount = (float)$stipend;

            $stmt->bind_param(
                "issssds",
                $company_id,
                $title,
                $description,
                $skills,
                $location,
                $stipendAmount,
                $duration
            );

            if ($stmt->execute()) {
                $message = "Internship added successfully!";
                $messageType = "success";
                $_POST = [];
            } else {
                $message = "Unable to add internship. Check your database table columns.";
                $messageType = "error";
            }

            $stmt->close();
        } else {
            $message = "Database query failed. Check your internships table.";
            $messageType = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Internship | Internship Portal</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f3f6fb;
    color: #243047;
}

.navbar {
    background: #ffffff;
    padding: 18px 7%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 10px #0000000d;
}

.logo {
    color: #1769d1;
    font-size: 23px;
    font-weight: bold;
}

.navbar a {
    text-decoration: none;
    color: #263449;
    margin-left: 20px;
}

.container {
    max-width: 760px;
    margin: 40px auto;
    padding: 0 18px;
}

.form-card {
    background: white;
    padding: 32px;
    border-radius: 14px;
    box-shadow: 0 8px 30px #1c355710;
}

h1 {
    margin-top: 0;
    color: #17365d;
}

.subtitle {
    color: #718096;
    margin-bottom: 25px;
}

label {
    display: block;
    margin: 17px 0 7px;
    font-weight: bold;
}

input, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #d5deea;
    border-radius: 7px;
    font-size: 15px;
    font-family: inherit;
}

textarea {
    min-height: 110px;
    resize: vertical;
}

input:focus, textarea:focus {
    outline: none;
    border-color: #1769d1;
}

button {
    width: 100%;
    padding: 14px;
    margin-top: 25px;
    border: none;
    border-radius: 8px;
    background: #1769d1;
    color: white;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
}

button:hover {
    background: #1055ad;
}

.message {
    padding: 13px;
    border-radius: 7px;
    margin-bottom: 18px;
}

.success {
    background: #e5f8ed;
    color: #167442;
}

.error {
    background: #ffeded;
    color: #b42318;
}

@media (max-width: 600px) {
    .navbar {
        padding: 16px;
        gap: 12px;
        flex-wrap: wrap;
    }

    .navbar a {
        margin-left: 8px;
    }

    .form-card {
        padding: 22px;
    }
}
</style>
</head>

<body>

<nav class="navbar">
    <div class="logo">Internship Portal</div>
    <div>
        <a href="dashboard.php">Dashboard</a>
        <a href="internships.php">My Internships</a>
        <a href="profile.php">Profile</a>
    </div>
</nav>

<div class="container">
    <div class="form-card">

        <h1>Add New Internship</h1>
        <p class="subtitle">
            Enter the internship details to publish an opportunity for students.
        </p>

        <?php if ($message !== ''): ?>
            <div class="message <?= htmlspecialchars($messageType) ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">

            <label for="title">Internship Title *</label>
            <input type="text" id="title" name="title"
                placeholder="e.g. Web Development Intern"
                value="<?= htmlspecialchars($_POST['title'] ?? '') ?>"
                required>

            <label for="description">Description *</label>
            <textarea id="description" name="description"
                placeholder="Describe the internship role..."
                required><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>

            <label for="skills">Required Skills *</label>
            <input type="text" id="skills" name="skills"
                placeholder="PHP, MySQL, HTML, CSS"
                value="<?= htmlspecialchars($_POST['skills'] ?? '') ?>"
                required>

            <label for="location">Location *</label>
            <input type="text" id="location" name="location"
                placeholder="e.g. Chennai / Remote"
                value="<?= htmlspecialchars($_POST['location'] ?? '') ?>"
                required>

            <label for="stipend">Monthly Stipend (₹) *</label>
            <input type="number" id="stipend" name="stipend"
                min="0" step="0.01"
                placeholder="e.g. 10000"
                value="<?= htmlspecialchars($_POST['stipend'] ?? '') ?>"
                required>

            <label for="duration">Duration *</label>
            <input type="text" id="duration" name="duration"
                placeholder="e.g. 3 months"
                value="<?= htmlspecialchars($_POST['duration'] ?? '') ?>"
                required>

            <button type="submit">Publish Internship</button>

        </form>
    </div>
</div>

</body>
</html>